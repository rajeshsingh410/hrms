import { useState } from "react";
import {
  StyleSheet,
  TouchableOpacity,
  View,
  TextInput,
  Modal,
  ScrollView,
  Platform,
} from "react-native";
import { Text } from "react-native-gesture-handler";
import Ionicons from "react-native-vector-icons/Ionicons";
import moment from "moment";
import { useNavigation } from "@react-navigation/native";
import DateTimePicker from "@react-native-community/datetimepicker";
import { useDispatch, useSelector } from "react-redux";
import {
  getTaskasync,
  updateDailyTask,
} from "../../services/Actions/employeeAction";

const themeColor = "#E95535";

const TaskCard = ({ item, type }) => {

  const { employee } = useSelector((state) => state.employee);
  const navigation = useNavigation();
  const dispatch = useDispatch();

  // === STATES ===
  const [expanded, setExpanded] = useState(false);
  const [showIssueInput, setShowIssueInput] = useState(false);
  const [issueText, setIssueText] = useState("");
  const [showDescModal, setShowDescModal] = useState(false);
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [showEmployeeList, setShowEmployeeList] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("");
  const [statusDate, setStatusDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [remark, setRemark] = useState("");

  // === HANDLERS ===
  const handleSaveIssue = () => {
    if (!issueText.trim()) return;
    // You can add dispatch or API call to send comment here
    setIssueText("");
    setShowIssueInput(false);
  };

  const handleStatusChange = (status) => {
    setSelectedStatus(status);
    setStatusDate(new Date());
    setRemark("");
    setShowStatusMenu(false);
    setShowStatusModal(true);
  };

  const handleSubmitStatus = (id) => {
    const formData = new FormData();
    formData.append("action", "update_daily_task");
    formData.append("id", id);
    formData.append("status", selectedStatus);
    formData.append("today", moment(statusDate).format("YYYY-MM-DD"));
    formData.append("remark", remark);
    formData.append("actionBy", employee.empid);

    dispatch(updateDailyTask(formData)).then(() => {
      dispatch(getTaskasync(employee?.empid));
    });

    setShowStatusModal(false);
  };

  const handleDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || statusDate;
    setShowDatePicker(Platform.OS === "ios");
    setStatusDate(currentDate);
  };

  const shortDescription =
    item.description && item.description.length > 70
      ? item.description.substring(0, 70) + "..."
      : item.description;

  return (
    <View
      style={[
        styles.card,
        { borderLeftColor: statusBadgeStyle(item.current_status).backgroundColor },
      ]}
    >
      {/* HEADER */}
      <TouchableOpacity
        style={styles.header}
        activeOpacity={0.7}
        onPress={() => setExpanded(!expanded)}
      >
        <View style={styles.headerLeft}>
          {/* Status Circle */}
          <View style={[styles.statusCircle, statusBadgeStyle(item.current_status)]}>
            <Text style={styles.statusLetter}>
              {item.current_status?.charAt(0) || "?"}
            </Text>
          </View>

          {/* Title */}
          <Text style={styles.title}>{item.title}</Text>
        </View>

        {/* Dropdown Arrow */}
        <Ionicons
          name={expanded ? "chevron-up" : "chevron-down"}
          size={18}
          color="#555"
        />
      </TouchableOpacity>

      {/* EXPANDED SECTION */}
      {expanded && (
        <>
          {/* STATUS + ASSIGN INFO */}
          <View style={styles.rowBetween}>

            {/* Assigned Info */}
            {type === "myTask" ? (
              <Text style={styles.subTitle}>
                <Ionicons name="person-outline" size={12} />{" "}
                {item.assignByName || "—"}
              </Text>
            ) : item.assignedToNames?.length > 1 ? (
              <TouchableOpacity onPress={() => setShowEmployeeList(true)}>
                <Text style={[styles.subTitle, { color: "#007bff" }]}>
                  Assigned to {item.assignedToNames.length} Employees
                </Text>
              </TouchableOpacity>
            ) : (
              <Text style={styles.subTitle}>
                <Ionicons name="person-outline" size={12} />{" "}
                {item.assignedToNames?.[0] || "—"}
              </Text>
            )}

            {/* Status Tag */}
            {
              type === "myTask" && (
                <TouchableOpacity
                  style={[styles.statusTag, statusBadgeStyle(item.status)]}
                  onPress={() => setShowStatusMenu(!showStatusMenu)}
                >
                  <Text style={styles.statusText}>{item.current_status}</Text>
                  <Ionicons name="chevron-down" size={14} color="#fff" />
                </TouchableOpacity>
              )
            }
          </View>

          {/* STATUS MENU */}
          {showStatusMenu && (
            <View style={styles.floatingStatusMenu}>
              {["Pending", "In Progress", "Completed", "Hold", "Reopened"].map(
                (status) => (
                  <TouchableOpacity
                    key={status}
                    onPress={() => handleStatusChange(status)}
                    style={styles.statusOption}
                  >
                    <Text style={{ color: "#333" }}>{status}</Text>
                  </TouchableOpacity>
                )
              )}
            </View>
          )}

          {/* EMPLOYEE LIST MODAL */}
          <Modal visible={showEmployeeList} transparent animationType="fade">
            <View style={styles.modalOverlay}>
              <View style={styles.modalBox}>
                <Text style={styles.modalTitle}>Assigned Employees</Text>
                {item.assignedToNames?.map((emp, idx) => (
                  <Text key={idx} style={styles.modalItem}>
                    👤 {emp}
                  </Text>
                ))}
                <TouchableOpacity
                  onPress={() => setShowEmployeeList(false)}
                  style={styles.closeBtn}
                >
                  <Text style={{ color: "#fff" }}>Close</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>

          {/* DESCRIPTION */}
          <TouchableOpacity
            style={styles.descContainer}
            onPress={() =>
              item.description?.length > 70 && setShowDescModal(true)
            }
          >
            <View style={styles.descHeader}>
              <Ionicons name="document-text-outline" size={18} color="#555" />
              <Text style={styles.descLabel}>Task Description</Text>
            </View>
            <Text style={styles.description}>{shortDescription}</Text>
            {item.description?.length > 70 && (
              <Text style={styles.tapHint}>Tap here to read more...</Text>
            )}
          </TouchableOpacity>

          {/* FOOTER */}
          <View style={styles.footer}>
            <View style={styles.dateInfo}>
              <Text style={styles.footerText}>
                <Ionicons name="calendar-outline" size={12} /> Assigned:{" "}
                {moment(item.assignDate).format("DD MMM YYYY")}
              </Text>
              <Text style={styles.footerText}>
                <Ionicons name="time-outline" size={12} /> Deadline:{" "}
                {moment(item.deadline).format("DD MMM YYYY")}
              </Text>
            </View>

            <View style={styles.actions}>
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("TaskDocuments", { task: item })
                }
                style={styles.actionIcon}
              >
                <Ionicons
                  name="folder-open-outline"
                  size={20}
                  color={themeColor}
                />
                <Text style={styles.iconLabel}>Docs</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => setShowIssueInput(!showIssueInput)}
                style={styles.actionIcon}
              >
                <Ionicons
                  name="chatbubble-ellipses-outline"
                  size={20}
                  color={themeColor}
                />
                <Text style={styles.iconLabel}>Message</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("TaskHistory", { task: item })
                }
                style={styles.actionIcon}
              >
                <Ionicons
                  name="information-circle-outline"
                  size={20}
                  color={themeColor}
                />
                <Text style={styles.iconLabel}>Info</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* COMMENT BOX */}
          {showIssueInput && (
            <View style={styles.issueBox}>
              <TextInput
                value={issueText}
                onChangeText={setIssueText}
                placeholder="Write a comment..."
                style={styles.issueInput}
              />
              <TouchableOpacity onPress={handleSaveIssue} style={styles.saveBtn}>
                <Text style={{ color: "#fff", fontWeight: "600" }}>Send</Text>
              </TouchableOpacity>
            </View>
          )}
        </>
      )}

      {/* === DESCRIPTION MODAL === */}
      <Modal
        visible={showDescModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowDescModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Task Description</Text>
              <TouchableOpacity onPress={() => setShowDescModal(false)}>
                <Ionicons name="close-circle" size={26} color="#555" />
              </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={styles.modalDesc}>{item.description}</Text>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* === STATUS UPDATE MODAL === */}
      <Modal
        visible={showStatusModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowStatusModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Update Status</Text>
              <TouchableOpacity onPress={() => setShowStatusModal(false)}>
                <Ionicons name="close-circle" size={26} color="#555" />
              </TouchableOpacity>
            </View>

            <ScrollView>
              {/* Date Picker */}
              <TouchableOpacity
                style={styles.datePickerBtn}
                onPress={() => setShowDatePicker(true)}
              >
                <Ionicons name="calendar-outline" size={18} color="#555" />
                <Text style={styles.datePickerText}>
                  {moment(statusDate).format("DD MMM YYYY")}
                </Text>
              </TouchableOpacity>
              {showDatePicker && (
                <DateTimePicker
                  value={statusDate}
                  mode="date"
                  display="default"
                  onChange={handleDateChange}
                />
              )}

              {/* Task Name */}
              <Text style={styles.inputLabel}>Task Name</Text>
              <TextInput
                value={item.title}
                editable={false}
                style={[styles.input, { backgroundColor: "#eee" }]}
              />

              {/* Remark */}
              <Text style={styles.inputLabel}>Remark</Text>
              <TextInput
                value={remark}
                onChangeText={setRemark}
                placeholder="Write a remark..."
                style={styles.input}
                multiline
              />

              {/* Submit */}
              <TouchableOpacity
                onPress={() => handleSubmitStatus(item.id)}
                style={styles.submitBtn}
              >
                <Text style={{ color: "#fff", fontWeight: "600" }}>Submit</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default TaskCard;

/* === STATUS BADGE COLOR === */
const statusBadgeStyle = (status) => {
  switch (status) {
    case "Pending":
      return { backgroundColor: "#FFA500" }; // Orange
    case "In Progress":
      return { backgroundColor: "#1E90FF" }; // Dodger Blue
    case "Completed":
      return { backgroundColor: "#32CD32" }; // Lime Green
    case "Reopened":
      return { backgroundColor: "#FF4500" }; // Orange Red
    case "Hold":
      return { backgroundColor: "#A9A9A9" }; // Dark Gray
    default:
      return { backgroundColor: "#4682B4" }; // Steel Blue
  }
};


/* === STYLES === */
const styles = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    borderRadius: 10,
    marginBottom: 14,
    padding: 12,
    elevation: 3,
    borderLeftWidth: 5,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: 8 },
  statusCircle: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
  },
  statusLetter: { color: "#fff", fontWeight: "700", fontSize: 13 },
  title: { fontSize: 15, fontWeight: "700", color: "#222", flexShrink: 1 },
  subTitle: { fontSize: 12, color: "#777", marginTop: 8 },
  statusTag: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 20,
    paddingHorizontal: 8,
    paddingVertical: 4,
    alignSelf: "flex-end",
    marginTop: 6,
    gap: 4,
  },
  statusText: { color: "#fff", fontSize: 11, fontWeight: "600" },
  floatingStatusMenu: {
    position: "absolute",
    top: 80,
    right: 10,
    zIndex: 999,
    elevation: 10,
    backgroundColor: "#fff",
    borderRadius: 6,
    borderWidth: 0.6,
    borderColor: "#ddd",
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
  statusOption: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderBottomWidth: 0.5,
    borderColor: "#eee",
  },
  descContainer: {
    backgroundColor: "#f9f9f9",
    borderRadius: 8,
    padding: 8,
    marginVertical: 8,
  },
  descHeader: { flexDirection: "row", alignItems: "center", marginBottom: 3, gap: 6 },
  descLabel: { fontSize: 13, fontWeight: "600", color: "#444" },
  description: { fontSize: 13, color: "#555", lineHeight: 18 },
  tapHint: { fontSize: 11, color: themeColor, marginTop: 3, fontStyle: "italic" },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderTopWidth: 0.5,
    borderColor: "#eee",
    paddingTop: 8,
  },
  footerText: { fontSize: 12, color: "#555" },
  dateInfo: { gap: 2 },
  actions: { flexDirection: "row", gap: 10 },
  actionIcon: { alignItems: "center" },
  iconLabel: { fontSize: 10, color: "#555", marginTop: 2 },
  issueBox: {
    marginTop: 6,
    borderTopWidth: 0.5,
    borderColor: "#ddd",
    paddingTop: 6,
  },
  issueInput: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 5,
    fontSize: 13,
  },
  saveBtn: {
    marginTop: 6,
    alignSelf: "flex-end",
    backgroundColor: themeColor,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 6,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalBox: {
    width: "88%",
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 14,
    maxHeight: "80%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  modalTitle: { fontSize: 15, fontWeight: "700", color: "#333" },
  modalDesc: { fontSize: 13, color: "#555", lineHeight: 20 },
  datePickerBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    padding: 8,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    marginBottom: 10,
  },
  datePickerText: { fontSize: 14, color: "#333" },
  inputLabel: { fontSize: 13, fontWeight: "600", marginTop: 10 },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 5,
    fontSize: 13,
    marginTop: 4,
  },
  submitBtn: {
    marginTop: 14,
    backgroundColor: themeColor,
    paddingVertical: 8,
    borderRadius: 8,
    alignItems: "center",
  },
  modalItem: { fontSize: 14, color: "#444", marginVertical: 3 },
  closeBtn: {
    marginTop: 12,
    backgroundColor: themeColor,
    paddingVertical: 6,
    borderRadius: 6,
    alignItems: "center",
  },
  rowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginVertical: 5,
  },
});
