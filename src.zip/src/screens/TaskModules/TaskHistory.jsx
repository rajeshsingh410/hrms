import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Modal,
  Pressable,
} from "react-native";
import Icon from "react-native-vector-icons/Ionicons";
import moment from "moment";
import { useDispatch } from "react-redux";
import { getMyTaskHistory } from "../../services/Actions/employeeAction";

const themeColor = "#2e8bff";

const TaskHistory = ({ route }) => {
  const { task } = route.params;
  const dispatch = useDispatch();
  const [cards, setCards] = useState([]);

  // 🔹 Modal states
  const [modalVisible, setModalVisible] = useState(false);
  const [modalText, setModalText] = useState("");

  const handleShowFullText = (text) => {
    setModalText(text);
    setModalVisible(true);
  };

  useEffect(() => {
    if (task?.id) {
      dispatch(getMyTaskHistory(task.id)).then((res) => {
        if (res?.status && Array.isArray(res.data)) {
          let cardGroups = [];
          let currentGroup = [];

          res.data.forEach((item, index) => {
            let details = [];

            if (item.status === "Assigned") {
              details.push(`Task created and assigned.`);
              if (item.description) details.push(item.description);
            } else if (item.status === "In Progress") {
              details.push(item.remark || "Task is currently in progress.");
            } else if (item.status === "Completed") {
              details.push("Task has been completed successfully By");
            } else if (item.status === "Reopened") {
              details.push(item.remark || "Task reopened due to an issue.");
            } else if (item.status === "Hold") {
              details.push(item.remark || "Task has been Hold By");
            }

            const step = {
              title: item.status,
              date: moment(item.assignDate).format("DD MMM YYYY"),
              details,
              active: true,
              deadline: item.deadline,
            };

            currentGroup.push(step);

            // if (item.status === "Reopened") {
            //   cardGroups.push([...currentGroup]);
            //   currentGroup = [];
            // }

            if (index === res.data.length - 1) {
              cardGroups.push([...currentGroup]);
            }
          });

          setCards(cardGroups);
        } else {
          setCards([]);
        }
      });
    }
  }, [task, dispatch]);

  return (
    <View style={{ flex: 1 }}>
      <ScrollView style={styles.container}>
        {cards.length > 0 ? (
          cards.map((steps, cardIndex) => (
            <View key={cardIndex} style={styles.card}>
              <Text style={styles.cardTitle}>
                Task Timeline {cardIndex > 0 ? `(#${cardIndex + 1})` : ""}
              </Text>

              {steps.map((step, index) => (
                <View key={index} style={styles.stepContainer}>
                  <View style={styles.iconContainer}>
                    <View
                      style={[
                        styles.circle,
                        step.active ? styles.circleActive : styles.circleInactive,
                      ]}
                    >
                      {step.active && <Icon name="checkmark" size={14} color="#fff" />}
                    </View>
                    {index !== steps.length - 1 && (
                      <View style={styles.verticalLine}></View>
                    )}
                  </View>

                  <View style={styles.textContainer}>
                    <Text style={[styles.title, step.active && styles.activeTitle]}>
                      {step.title}{" "}
                      <Text style={styles.date}>{step.date}</Text>
                    </Text>

                    {step.details.map((line, i) => {
                      //   const words = line.trim().split(/\s+/);
                      if (line.length > 50) {

                        const shortText = line.substring(0, 50) + "...";
                        return (
                          <TouchableOpacity
                            key={i}
                            activeOpacity={0.7}
                            onPress={() => handleShowFullText(line)}
                          >
                            <Text style={[styles.detailText]}>
                              {shortText}{" "}
                              <Text style={styles.readMore}>Read more</Text>
                            </Text>
                          </TouchableOpacity>
                        );
                      } else {
                        return (
                          <Text key={i} style={styles.detailText}>
                            {line}
                          </Text>
                        );
                      }
                    })}
                  </View>
                </View>
              ))}

              {steps[steps.length - 1]?.deadline && (
                <View style={styles.deadlineContainer}>
                  <Icon name="calendar" size={16} color={themeColor} />
                  <Text style={styles.deadlineText}>
                    Expected Completion:{" "}
                    {moment(steps[steps.length - 1].deadline).format("DD MMM YYYY")}
                  </Text>
                </View>
              )}
            </View>
          ))
        ) : (
          <Text style={{ color: "#777", textAlign: "center", marginTop: 20 }}>
            No task history found.
          </Text>
        )}
      </ScrollView>

      {/* ✅ Modal for full text */}
      <Modal
        visible={modalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setModalVisible(false)}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Full Details</Text>
            <ScrollView style={{ maxHeight: 300 }}>
              <Text style={styles.modalText}>{modalText}</Text>
            </ScrollView>
            <TouchableOpacity
              style={styles.closeBtn}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.closeText}>Close</Text>
            </TouchableOpacity>
          </View>
        </Pressable>
      </Modal>
    </View>
  );
};

export default TaskHistory;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f2f2f2",
    padding: 16,
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 16,
    elevation: 3,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 12,
    color: "#333",
  },
  stepContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 20,
  },
  iconContainer: {
    alignItems: "center",
    width: 30,
  },
  circle: {
    width: 18,
    height: 18,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  circleActive: {
    backgroundColor: themeColor,
  },
  circleInactive: {
    borderWidth: 1.5,
    borderColor: "#ccc",
    backgroundColor: "#fff",
  },
  verticalLine: {
    width: 2,
    flex: 1,
    backgroundColor: "#ccc",
    marginTop: 4,
  },
  textContainer: {
    flex: 1,
    paddingLeft: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: "600",
    color: "#000",
  },
  activeTitle: {
    color: themeColor,
  },
  date: {
    fontSize: 13,
    fontWeight: "400",
    color: "#777",
  },
  detailText: {
    color: "#555",
    fontSize: 13,
    marginTop: 2,
  },
  readMore: {
    color: "#E95535",
    textDecorationLine: "underline",
    fontWeight: "500",
  },
  deadlineContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
  },
  deadlineText: {
    marginLeft: 6,
    fontSize: 13,
    color: themeColor,
    fontWeight: "500",
  },
  // 🔹 Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  modalBox: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 10,
    width: "100%",
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#333",
    marginBottom: 10,
  },
  modalText: {
    fontSize: 14,
    color: "#444",
    lineHeight: 20,
  },
  closeBtn: {
    marginTop: 15,
    alignSelf: "center",
    backgroundColor: "#E95535",
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 6,
  },
  closeText: {
    color: "#fff",
    fontWeight: "600",
  },
});
