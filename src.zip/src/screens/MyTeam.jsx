import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const MyTeam = () => {
  return (
    <View>
      <Text>MyTeam</Text>
    </View>
  )
}

export default MyTeam

const styles = StyleSheet.create({})